package encapsulation;

public class Encap_test
{
	// Abstract class --> (0 to 100%) --> abstract keyword --> we cannot create object. -->incomplete method --> "Concrete class"
	// Interface --> (100%) --> implements keyword --> can't create constructor --> "Implementation class"
	
	// Achieving data hiding
	// Process of hiding the internal implementation & producing external functionality is called encapsulation.
	
	
	
	
	
	
	
	
	
	
	// The process of binding the datamembers and its corresponding method into a single unit is called encapsulation.
	// To achieve the encapsulation
	/*
	 * 1. Declare the variables of the class as "private"
	 * 2. Provide Public getter and setter method in the class 
	 */

}
