package operator_demo;

public class Arithmatic_Op {

	static double a =10;
	static double b = 3;
	
	public static void main(String[] args)
	{	
		System.out.println(a);
		
		System.out.println("Addition"+ (a+b));  //13
		System.out.println("Substraction" + (a-b));
		System.out.println("Multiplication" + (a*b));
		System.out.println("Division"+ (a/b)); //3
		System.out.println("Reminder"+ (a%b));// 1
		
	}

}
