package non_Primitive_casting;

public class Subclass extends Superclass  // Son
{
	public void house ()
	{
		System.out.println("Son: House");
	}
	
	public void car ()
	{
		System.out.println("Son: car");
	}
	public void job ()
	{
		System.out.println("Son: Job");
	}
	

}
