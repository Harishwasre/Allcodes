package non_Primitive_casting;

public class Superclass // father
{
	public void house ()
	{
		System.out.println("Father: House");
	}
	
	public void car ()
	{
		System.out.println("Father: car");
	}
	
	public void land ()
	{
		System.out.println("Father: land");
	}

}
