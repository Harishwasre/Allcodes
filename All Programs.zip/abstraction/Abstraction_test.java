package abstraction;

public class Abstraction_test
{
	/*
	 * Two types of abstraction
	 * 1. Abstract Class (0 to 100%)
	 * 2. Interface (100%)
	 * 
	 * 
	 *  1. Abstract Class (0 to 100%)
	 *  Note:
	 *  1. "abstract" Keyword.
	 *  2. abstract as well as non abstract method
	 *  3. Abstract --> incomplete method
	 *  4. "abstract" keyword --> to declare the method.
	 *  5. For "abstract method" use " ; " to complete the method.
	 *  6. cannot create constructor of abstract class 
	 */

}
