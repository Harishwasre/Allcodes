package abstraction;

public abstract class Abstract_Test_Class
{
	public void name ()
	{
		System.out.println("Aspire");
	}
	public void  aadhar ()
	{
		System.out.println("123456789123");
	}
	abstract public void mobilenumber ();  // Abstract method
	
//	public static void main(String[] args)
//	{
//		Abstract_Test_Class a = new Abstract_Test_Class(); // Error --> in constructor
//		a.name();
//		a.aadhar();
//		a.mobilenumber();
//	}
	

}
