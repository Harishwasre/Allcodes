package for_Demo;

public class Simple_For {
	public static void main(String[] args)
	{
		// for loop
		// used to iterate the program
		// use the for loop when the number of iterations are fixed.
		// Scenario: Print 1 to 1000  // fixed value
		// Syntax: 
		// for (initialization; Condition; increment/decrement)
		for (int i=10; i>=1; i--)     // 1 --> 1    program will run <=10 i--
		{
			System.out.println(i);   // 2 +1=3+1=4+1.........10
			// 10+1=11 
		}
	}
}
