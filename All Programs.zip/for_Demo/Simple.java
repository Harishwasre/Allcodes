package for_Demo;

public class Simple {

	public static void main(String[] args)
	{
		//  Scenario: Print 1 to 1000  // fixed value
		// Scenario: Print 1 to infinity...... // infinite value
		
		System.out.println("1"+"2"+"3");
		//----
		//----
		//---
		System.out.println("10");
		// loop statement
		// for loop, while loop
	
	
		
	}

}
