package for_Demo;

public class Do_While_Loop {

	public static void main(String[] args)
	{
		// do while execute at least once
		
		// syntax: 
		/*
		 * do 	{
			Statement
				}
			while (Condition); */
		
		int a = 1;
		do {
			System.out.println(a);
			a++;
		} 
		while (a<=5);
	}
}

/*
 * if ()
 * {
 * 	for(){
 * 		}
 * } else
 *  {
 * 	}
 */














