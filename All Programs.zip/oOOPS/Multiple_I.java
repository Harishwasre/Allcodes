package oOOPS;

public class Multiple_I extends Father, Son // Not Possible in JAVA--> Showing error
{

	public static void main(String[] args)
	{

		// Can we achieve multiple in java for class --> No
		// one /interface can acquire the properties of multiple /interfaces at same time
		// Object class--> Supermost class in java / parent class in java
		// Diamond ambiguity
	}

}
