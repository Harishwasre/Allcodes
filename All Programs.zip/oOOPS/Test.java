package oOOPS;

public class Test {

	public static void main(String[] args)
	{
		Son s = new Son();  //Object --> Son Class
		s.Job();
		s.house();
		s.Car();
		
		
	}
}
