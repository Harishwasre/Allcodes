package oOOPS;

public class Son extends Father // extends--Keyword--> Acquire the properties from "father" class
{
	public void Job ()
	{
		System.out.println("Son: Job");
	}

}
