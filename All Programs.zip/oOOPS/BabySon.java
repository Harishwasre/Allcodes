package oOOPS;

public class BabySon extends Son
{
	public void cry ()
	{
		System.out.println("BabySon: Cry");
	}
	

}
