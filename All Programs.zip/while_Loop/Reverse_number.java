package while_Loop;

public class Reverse_number {

	public static void demo ()
	{
		int number = 6789;  //4321
		int temp;
		int rev=0;
		int a = number;
		
		while (number > 0)
		{
			temp = number%10;
			rev = (rev*10) +temp;
			number = number/10;
		}
		System.out.println("Expected number = "+ number +" "+a+ "   Actual Number="+rev);
	
	}
	public static void main(String[] args)
	{
		demo();
		
	}
}
