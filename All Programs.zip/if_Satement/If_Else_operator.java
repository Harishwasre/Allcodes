package if_Satement;

public class If_Else_operator
{
	public static void main(String[] args)
	{
		String user = "aspir";
		String pass = "team";
		if (user=="aspire" && pass=="team")
		{
			System.out.println("Click on the submit button");
		}
		else 
		{
			System.out.println("Your username or password is incorrect");
		}
	}
}
