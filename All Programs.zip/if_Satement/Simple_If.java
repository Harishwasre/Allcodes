package if_Satement;

public class Simple_If {

	public static void main(String[] args) 
	{
		int a = 10;  //Loacal Variable
		
		if (a>9) // if a>9 then enter into the if body
		{
			System.out.println("I am greater than 9");
		}
		
		if (a<9)  // a=10  this condition not satisfied
		{
			System.out.println("I am less than 9");
		}
		
	}

}
