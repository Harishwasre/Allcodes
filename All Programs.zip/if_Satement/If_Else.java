package if_Satement;

public class If_Else {

	public static void main(String[] args)
	{
		int a = 10;  // Loacal Variable
		
		if (a<9)  // a=10 <9 --> enter into the if body
		{
			System.out.println("I am less than 9");
		}
		else //  a=10 >9 --> enter into the else body
		{
			System.out.println("I am greater than 9");
		}
		
		if (a>9)  // 
		{
			System.out.println("I am less than 9");
		}
		else //  
		{
			System.out.println("I am greater than 9");
		}
	}

}
