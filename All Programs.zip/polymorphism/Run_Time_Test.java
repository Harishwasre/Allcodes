package polymorphism;

public class Run_Time_Test {

	public static void main(String[] args)
	{
		Run_Time_Subclass r = new Run_Time_Subclass();
		r.property(5);
		r.House("Aspire");
		
	}

}
