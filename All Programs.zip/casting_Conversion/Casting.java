package casting_Conversion;

public class Casting 
{
	// information
	// Two types
	// 1. Primitive casting --> byte, short, int, long, float, double,  
	// We are not doing casting of char datatype -->'a', boolean,
	// 2. non-Primitive Casting

}
