package casting_Conversion;

public class Non_Primitive_Casting
{
	// 1. We need to do the inheritance
	// 2. Types
	//	1.up-casting
	//	2.Down-casting
	

}
