package demo;

public class Program {

	
		// Class
		// 1. Methods/ member function
		// 1. Main method
		public static void main (String[] args)
		{      
			System.out.println("First Line " + "\nSecond Line" + 123456789);  // Printing Statement
			System.out.println(123456);
			
			// System.out.println("Second Line");
			// System.out.print("Third Line");
		}
		
		// public--> Access modifier
		// static --> stable
		// void --> return type
		// main --> name 
		// () --> Method Signature
		// (String[] args) -->array creation.
		// it reserve the space for program JVM
		// {}--> Method body
		
		// 2. Business method / Regular method
		
		
		
		
		
		
		
		
		
		
		
		
		// 2. Printing Statement
		// 3. Variables
		// 4. Constructor
		// 5. datatypes
		// 6. Objects
		// 7. Loop statement
		// 8. Control statement
		// 9. Operators
		// 10. Scanning statement 
		// 11. etc
		
		//HW
		// Write-->JDK, JRE & JVM
		// Classification of java
		// Content present in class

	

}
