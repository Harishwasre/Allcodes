package demo;   //statement or syntax

class First_Program
{
	// 
	// syntax package is 
	// package packageName;
	// ; --> used to end the statement
	// My name is Aspire. 
	
	// class syntax:
	// class ClassName
	public static void main (String [] args) 
	{
		//System.out.println("First Project");
		System.out.println ("Hi");
	
	}
}

