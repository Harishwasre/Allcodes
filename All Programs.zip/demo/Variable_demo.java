package demo;

public class Variable_demo 
{
	// to store something into the program we required variables
	// V are nothing but the piece of memory used to store the info.
	// datatype referencevariable = information;    syntax
	
	
	public static void main (String[] args)
	{
		String p = "pune";

		int i = 123;
		
		System.out.println(p + "   "+ i);
	}
}
