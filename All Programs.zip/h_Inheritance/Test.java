package h_Inheritance;

public class Test
{
	public static void main(String[] args)
	{
		Payment m = new Payment();
		m.login();
		m.oneplus();
		m.payment();
		
		
		
		Furniture f = new Furniture();
		f.login();
		f.Table();
		
	}
}
