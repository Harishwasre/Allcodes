package h_Inheritance;

public class Payment extends Mobile
{
	public void payment ()
	{
		System.out.println("Make payment");
	}
	

}
