package h_Inheritance;

public class Mobile extends H_Inheritance_Super
{
	public void oneplus ()
	{
		System.out.println("oneplus");
	}
}
