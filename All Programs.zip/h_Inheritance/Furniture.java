package h_Inheritance;

public class Furniture extends H_Inheritance_Super
{
	public void Table ()
	{
		System.out.println("table");
	}

}
