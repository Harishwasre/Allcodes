package h_Inheritance;

public class H_Inheritance_Super
{
	// Only one superclass & Multiple subclasses
	public void login ()
	{
		System.out.println("Login to Amazon");
	}

}
