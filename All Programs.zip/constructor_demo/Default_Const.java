package constructor_demo;

public class Default_Const
{
	// Declaration
	static int a;
	static String b;
	
	//initialization
	/*
	 * Default_Const ()
	 * {
	 *  a =0;
	 *  b = "null";
	 * }
	 */
	
	// usage
	public static void main(String[] args)
	{
		// default const
		System.out.println(a);
		System.out.println(b);
		
	}

}
